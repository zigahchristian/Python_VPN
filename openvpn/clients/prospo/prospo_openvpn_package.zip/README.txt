OpenVPN Client Package for prospo

Files included:
1. prospo.ovpn - Main OpenVPN configuration file
2. prospo.crt - Client certificate
3. prospo.key - Client private key
4. tls-crypt.key - TLS encryption key


Setup Instructions:
1. Extract all files to a secure location
2. Install OpenVPN client on your device
3. Import prospo.ovpn file into OpenVPN

5. Connect to the VPN

Generated: 2026-02-05T13:27:47.813797
Certificate Expires: 2027-02-05
Auto-delete: Enabled - Certificate will be automatically deleted after expiration
